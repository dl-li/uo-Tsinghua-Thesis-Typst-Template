#let settings = (

作者名: "某某某",

论文题目:[
  博士生资格考试书面报告题目
], // 换行需空行

副标题: "博士生资格考试书面报告",

院系: "基础医学院",

专业: "基础医学",

导师: "某某某 教授",

副导师: none,

// 日期: datetime(year: 2028, month: 12, day: 1), //默认为当前日期

关键词_英: ("Keyword1", "Keyword2", "Keyword3"),

目录深度: 3,

字体: ( 
  仿宋: ("Times New Roman", "FangSong"),
  宋体: ("Times New Roman", "SimSun"),
  黑体: ("Arial","SimHei"),
  楷体: ("Times New Roman", "KaiTi"),
  代码: ("DejaVu Sans Mono"),
),

引文格式: "cell", // https://typst.app/docs/reference/model/bibliography/#parameters-style

)





#let 摘要_英 = [

    #lorem(100)

]


















// ==================================
//
//          以下内容不要编辑
//
// ==================================

#let other_contents = (
  摘要_英:摘要_英, 
)

#import "lib_bozikao.typ": *

// tablem包: 允许使用类markdown语法绘制表格
#import "@preview/tablem:0.2.0": tablem

// 可以自动显示续表题的三线表
#let three-line-table = tablem.with(
  render: (caption, columns: auto, headline,..cells) => {
    [
      #let firstHeader = state("fh",true)//标记是否是第一个表头的状态
      #table(
        columns: columns,
        column-gutter: 1.5em,
        inset: (
          x: 1em,
          y: 0.6em,
        ),
        stroke: none,
        align: center + horizon,
        table.hline(y: 1, stroke: 1.5pt),
        table.hline(y: 2, stroke: 1pt),
        table.header(
          // 自动“续表”的实现方式：利用表格的header跨页会重复显示的特性，不显示原有figure默认的caption，而是手动把它放到表格的header中表头的上一行（合并一整行），再根据是否首次显示判定是“表”还是“续表”
          table.cell(colspan: columns,[
            #set text(11pt)
            #context{
              [Table ]
              let loc = query(selector(figure.where(kind:table)).before(here())).last().location()
              chinesenumbering(chaptercounter.at(loc).first(),
              counter(figure.where(kind: table)).at(loc).first()) //手动生成表的编号
            }
            ~~
            #caption //表题本体
            #context {
              if firstHeader.get(){
                firstHeader.update(false)
              }else{
                [(Continued)]
              }
            }
            #v(3pt)
          ]),
          ..headline.children //表头
        ),
        ..cells, //表格的其余部分
        table.hline(stroke: 1.5pt),
      )
      #firstHeader.update(true)
    ]
  }
)

// biaoge: 可以生成带有标签和表题的三线表
#let biaogeHint = [
  |#text(red,font: 字体.黑体)[【`#biaoge(...)` 使用方法】]|<|
  | -------------- | -------------- |
  | caption:       | [表题]          |
  | body:          | [Markdown表格]  | 
  | label:         | \<标签\>，可不填 |
  | 合并单元格      | `^`或`<`        |
]
#let biaoge(caption:text(red,font: 字体.黑体)[【未命名表格】], body: biaogeHint, label: none) = {
  align(center)[
    #show figure: set block(breakable: true)
    #figure(
      caption: caption,
      three-line-table(caption, body),
    ) #label
  ]
}

#let tupian(body: "images/tupianhint.png", width:70%, caption: text(red,font: 字体.黑体)[【未命名图片】], legend: none, label: none)={  
  align(center)[
    #block(breakable: false)[
      #figure(
      image(body, width: width),
      caption: caption
      ) #label
      #if legend != none{
        v(-12pt)
        set align(left)
        set par(justify: true, first-line-indent: 0pt)
        text(10.5pt)[#legend]
        v(12pt)
      }
    ]
  ]
}