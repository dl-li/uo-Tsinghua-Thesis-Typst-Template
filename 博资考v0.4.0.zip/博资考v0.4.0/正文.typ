#import "lib_bozikao.typ": conf
#import "设置与其他.typ": settings, other_contents, tupian, biaoge
#show: this_doc => conf(..settings, doc: this_doc, others: other_contents)

= Level-1 Heading Example

  == Requirements
    3,000~5,000 words (#sym.lt 5,000 words not including reference).Times New Roman or Arial, font size 10.5-11; single or 1.25-line spaced; No more than 8 display figures/tables. Scientific writing should avoid colloquialism and mistakes in spelling and grammar.

    
  == Level-2 Heading Example 

    // #lorem()用于生成随机占位文本
    #lorem(10) 

    #tupian(
      body: "images/tupianhint.png",
      caption: [Example of a figure caption],
      legend: [(a) #lorem(20) (b) #lorem(20)],
      label: <fig:example>
    ) 

    @fig:example is an example of a figure. 

    === Lever-3 Heading Example

      #lorem(35)

      #biaoge(
        caption: [Example of a table caption],
        body: [ 
          | *Name*  | *Location*   | *Height* | *Score* |
          | ------- | ------------ | -------- | ------- |
          | John    | Second St.   | 180 cm   | 5       |
          | Wally   | Third Av.    | 160 cm   | 10      |
          | Sarah   | Fifth Rd.    | 172 cm   | 8       |
          | Michael | Seventh Blvd | 185 cm   | 7       |
          | Emily   | Fourth Ln.   | 168 cm   | 9       |
          | David   | ^            | 178 cm   | <       |
        ],
        label: <tab:example>
      )

      @tab:example is an example of a table. 

  == Citation

      Now citing the AlphaFold3 paper @AF3 .


= Specific Aims

  A one-page statement of your objectives for the project. This is the *most important* page. Think of the one-page Specific Aims as a capsule of your entire Research Plan. This page opens with focused introductory paragraph with necessary narratives (background, significance, central hypothesis) to help your audience grasp the proposal. Then propose 2-4 (most often 3) specific aims in half a page.


= Background and Significance

  A concise introduction of current knowledge _directly_ related to your proposed work, and raising the key questions to be answered in your study

= Preliminary Results

  This paper should be in the format of when you write results for a paper. Describe why and how the experiments are done and how you interpretate the results. Also please have very clear figure legends.

= Research Plan

  Please expand each aim, state the rationale of proposed experiments, briefly describe experimental approaches, discuss expected results and alternative outcome and/or hypothesis. 


// 参考文献
#bibliography("文献库.bib",
title: "References", 
style: settings.引文格式
)