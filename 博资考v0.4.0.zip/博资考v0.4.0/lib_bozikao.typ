#import "@preview/a2c-nums:0.0.1": int-to-cn-simple-num
#import "@preview/cuti:0.3.0": show-cn-fakebold
#show: show-cn-fakebold


#let 字号 = (
  初号: 42pt,
  小初: 36pt,
  一号: 26pt,
  小一: 24pt,
  二号: 22pt,
  小二: 18pt,
  三号: 16pt,
  小三: 15pt,
  四号: 14pt,
  中四: 13pt,
  小四: 12pt,
  五号: 10.5pt,
  小五: 9pt,
  六号: 7.5pt,
  小六: 6.5pt,
  七号: 5.5pt,
  小七: 5pt,
)

#let 字体 = ( 
  仿宋: ("Times New Roman", "FangSong"),
  宋体: ("Times New Roman", "SimSun"),
  黑体: ("Arial","SimHei"),
  楷体: ("Times New Roman", "KaiTi"),
  代码: ("DejaVu Sans Mono"),
)

#let lengthceil(len, unit: 字号.小四) = calc.ceil(len / unit) * unit
#let partcounter = counter("part")
#let chaptercounter = counter("chapter")
#let appendixcounter = counter("appendix")
#let footnotecounter = counter(footnote)
#let rawcounter = counter(figure.where(kind: "code"))
#let imagecounter = counter(figure.where(kind: image))
#let tablecounter = counter(figure.where(kind: table))
#let equationcounter = counter(math.equation)
#let appendix() = {
  appendixcounter.update(50)
  chaptercounter.update(0)
  counter(heading).update(0)
}
#let skippedstate = state("skipped", false)

#let chinesenumber(num, standalone: false) = if num < 11 {
  ("零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十").at(num)
} else if num < 100 {
  if calc.rem(num, 10) == 0 {
    chinesenumber(calc.floor(num / 10)) + "十"
  } else if num < 20 and standalone {
    "十" + chinesenumber(calc.rem(num, 10))
  } else {
    chinesenumber(calc.floor(num / 10)) + "十" + chinesenumber(calc.rem(num, 10))
  }
} else if num < 1000 {
  let left = chinesenumber(calc.floor(num / 100)) + "百"
  if calc.rem(num, 100) == 0 {
    left
  } else if calc.rem(num, 100) < 10 {
    left + "零" + chinesenumber(calc.rem(num, 100))
  } else {
    left + chinesenumber(calc.rem(num, 100))
  }
} else {
  let left = chinesenumber(calc.floor(num / 1000)) + "千"
  if calc.rem(num, 1000) == 0 {
    left
  } else if calc.rem(num, 1000) < 10 {
    left + "零" + chinesenumber(calc.rem(num, 1000))
  } else if calc.rem(num, 1000) < 100 {
    left + "零" + chinesenumber(calc.rem(num, 1000))
  } else {
    left + chinesenumber(calc.rem(num, 1000))
  }
}

#let chinesenumbering(..nums, location: none, brackets: false) = context {
  let actual_loc = if location == none { here() } else { location }
  if appendixcounter.at(actual_loc).first() < 50 {
    if nums.pos().len() == 1 {
        [#nums.pos().first()] 
    } else {
      numbering(if brackets { "(1.1)" } else { "1.1" }, ..nums)
    }
  } else {
    if nums.pos().len() == 1 {
      "附录 " + numbering("A.1", ..nums)
    } else {
      numbering(if brackets { "(A.1)" } else { "A.1" }, ..nums)
    }
  }
}

#let chineseunderline(s, width: 300pt, bold: false) = {
  let chars = s.clusters()
  let n = chars.len()
  style(styles => {
    let i = 0
    let now = ""
    let ret = ()

    while i < n {
      let c = chars.at(i)
      let nxt = now + c

      if measure(nxt, styles).width > width or c == "\n" {
        if bold {
          ret.push(strong(now))
        } else {
          ret.push(now)
        }
        ret.push(v(-1em))
        ret.push(line(length: 100%))
        if c == "\n" {
          now = ""
        } else {
          now = c
        }
      } else {
        now = nxt
      }

      i = i + 1
    }

    if now.len() > 0 {
      if bold {
        ret.push(strong(now))
      } else {
        ret.push(now)
      }
      ret.push(v(-0.9em))
      ret.push(line(length: 100%))
    }

    ret.join()
  })
}

#let chineseoutline(title: "目　　录", depth: none, indent: false) = {
  heading(title, numbering: none, outlined: false)
  context{
    let it = here()
    let elements = query(heading.where(outlined: true).after(it))

    for el in elements {
      // Skip list of images and list of tables
      if partcounter.at(el.location()).first() < 20 and el.numbering == none { continue }

      // Skip headings that are too deep
      if depth != none and el.level > depth { continue }

      let maybe_number = if el.numbering != none {
        if el.numbering == chinesenumbering {
          chinesenumbering(..counter(heading).at(el.location()), location: el.location())
        } else {
          numbering(el.numbering, ..counter(heading).at(el.location()))
        }
        h(0.5em)
      }

      let line = {
        if indent {
          h(1em * (el.level - 1 ))
        }

        if el.level == 1 {
          v(0.5em, weak: true)
        }

        if maybe_number != none {
          //style(styles => {
          //  let width = measure(maybe_number, styles).width
            box(
              width: auto,//lengthceil(width),
              link(el.location(), if el.level == 1 {
                strong(maybe_number)
              } else {
                maybe_number
              })
            )
          //})
        }

        link(el.location(), if el.level == 1 {
          strong(el.body)
        } else {
          el.body
        })

        // Filler dots
        // if el.level == 1 {
        //   box(width: 1fr, h(10pt) + box(width: 1fr) + h(10pt))
        // } else {
           box(width: 1fr, h(10pt) + box(width: 1fr, repeat[.]) + h(10pt))
        // }

        // Page number
        let footer = query(selector(<__footer__>).after(el.location()))
        let page_number = if footer == () {
          0
        } else {
          counter(page).at(footer.first().location()).first()
        }
        
        link(el.location(), if el.level == 1 {
          strong(str(page_number))
        } else {
          str(page_number)
        })

        linebreak()
        v(-0.2em)
      }

      line
    }
  }
}

#let listoffigures(title: "插图清单", kind: image) = {
  heading(title, numbering: none, outlined: true)
  context{
    let it = here()
    let elements = query(figure.where(kind: kind).after(it))
    set par(spacing: 12pt)

    for el in elements {
      let maybe_number = {
        let el_loc = el.location()
        if kind == image{
          [图]
        } else if kind == table{
          [表]
        }
        chinesenumbering(chaptercounter.at(el_loc).first(), counter(figure.where(kind: kind)).at(el_loc).first(), location: el_loc)
        h(0.5em)
      }
      let line = {
        //style(styles => {
        //let width = measure(maybe_number, styles).width
          box(
            width: auto,//lengthceil(width),
            link(el.location(), maybe_number)
        //  )}
        )

        link(el.location(), el.caption.body)

        // Filler dots
        box(width: 1fr, h(10pt) + box(width: 1fr, repeat[.]) + h(10pt))

        // Page number
        let footers = query(selector(<__footer__>).after(el.location()))
        let page_number = if footers == () {
          0
        } else {
          counter(page).at(footers.first().location()).first()
        }
        link(el.location(), str(page_number))
        linebreak()
        v(-0.2em)
      }

      line
    }
  }
}

#let codeblock(raw, caption: none, outline: false) = {
  figure(
    if outline {
      rect(width: 100%)[
        #set align(left)
        #raw
      ]
    } else {
      set align(left)
      raw
    },
    caption: caption, kind: "code", supplement: ""
  )
}

#let booktab(columns: (), aligns: (), width: auto, caption: none, ..cells) = {
  let headers = cells.pos().slice(0, columns.len())
  let contents = cells.pos().slice(columns.len(), cells.pos().len())
  set align(center)

  if aligns == () {
    for i in range(0, columns.len()) {
      aligns.push(center)
    }
  }

  let content_aligns = ()
  for i in range(0, contents.len()) {
    content_aligns.push(aligns.at(calc.rem(i, aligns.len())))
  }

  /*return*/ figure(
    block(
      width: width,
      grid(
        columns: (auto),
        row-gutter: 1em,
        line(length: 100%),
        [
          #set align(center)
          #box(
            width: 100% - 1em,
            grid(
              columns: columns,
              ..headers.zip(aligns).map(it => [
                #set align(it.last())
                #strong(it.first())
              ])
            )
          )
        ],
        line(length: 100%),
        [
          #set align(center)
          #box(
            width: 100% - 1em,
            grid(
              columns: columns,
              row-gutter: 1em,
              ..contents.zip(content_aligns).map(it => [
                #set align(it.last())
                #it.first()
              ])
            )
          )
        ],
        line(length: 100%),
      ),
    ),
    caption: caption,
    kind: table
  )
}





#let conf(

作者名: "某某某",

论文题目:[
  博资考书面报告标题
], // 换行需空行

副标题: "博士生资格考试书面报告",

院系: "基础医学系",

专业: "基础医学",

导师: "某某某 教授",

副导师: none,

日期: datetime.today(), //默认为当前日期

关键词_英: ("Typst", "Template", [_Italic Text_]),

目录深度: 3,

右页起章: false, // 目前有bug

字体: ( 
  仿宋: ("Times New Roman", "FangSong"),
  宋体: ("Times New Roman", "SimSun"),
  黑体: ("Arial","SimHei"),
  楷体: ("Times New Roman", "KaiTi"),
  代码: ("DejaVu Sans Mono"),
),

引文格式: "cell",

others: none,

doc: none

) = {
  
  
  let pagebreakToRight = () => {
    if 右页起章 {
      skippedstate.update(true)
      pagebreak(to: "odd", weak: true)
      skippedstate.update(false)
    } else {
      pagebreak(weak: true)
    }
  }

set page("a4",
    header: context {
      //let currentPage = here().page()
      let nextFooterLoc = query(selector(<__footer__>).after(here())).first().location()
      let chaptersBefore = query(selector(heading.where(level:1)).before(nextFooterLoc))
      let currentChapNumber = chaptercounter.at(nextFooterLoc).first()
      if chaptersBefore != (){
        [
          #set align(center)
          #set text(字号.五号, font: 字体.宋体)
          #if currentChapNumber > 0 and chaptersBefore.last().numbering != none {chinesenumbering(currentChapNumber)+h(1em)}
          #chaptersBefore.last().body
          #v(-5pt)
          #line(length: 100%)
          #v(-18pt)
        ]
      }
    },
    footer: 
      context [
        #set align(center)
        #set text(字号.五号, font: 字体.宋体)
        #if query(selector(heading).before(here())) != () and page.numbering != none [
          #move(dy:-12pt,counter(page).display())
        ]#label("__footer__")
      ]
  )

  set text(字号.一号, font: 字体.宋体, lang: "en")
  set align(center + horizon)
  set heading(numbering: chinesenumbering)
  set figure(
    numbering: (..nums) => context { let loc = here()
      if appendixcounter.at(loc).first() < 10 {
        numbering("1.1", chaptercounter.at(loc).first(), ..nums)
      } else {
        numbering("A.1", chaptercounter.at(loc).first(), ..nums)
      }
    }
  )
  set math.equation(
    numbering: (..nums) => context { let loc = here()
      set text(font: 字体.宋体)
      if appendixcounter.at(loc).first() < 10 {
        numbering("(1.1)", chaptercounter.at(loc).first(), ..nums)
      } else {
        numbering("(A.1)", chaptercounter.at(loc).first(), ..nums)
      }
    }
  )
  set list(indent: 2em)
  set enum(indent: 2em)

  //show strong: it => text(font: 字体.黑体, weight: "semibold", it.body)
  //show emph: it => text(font: 字体.楷体, style: "italic", it.body)
  set par(first-line-indent: (amount: 2em, all: true))
  show raw: set text(font: 字体.代码)

  show heading: it => {
    set text(font: 字体.黑体, weight: "medium")
    set par(first-line-indent: 0em)
    let showHeading(it, size, above: 0em, below: 0em, hard_above: 0em, hard_below: 0em) = {
    set text(size)
      block(
        above: above, below: below,
        {
          v(hard_above)
          if it.numbering != none {
            counter(heading).display()
            h(1em)
          }
          it.body
          v(hard_below)
        }
      )
    }
    
    if it.level == 1 {
      
      // if not it.body.text in ("Abstract", "学位论文使用授权说明", "版权声明","摘　　要")  {
      if it.numbering != none{
        pagebreakToRight()
      } else{
        pagebreak()
      }
      
      //locate(loc => {
        context { let loc = here()
          if it.body.text == "摘　　要" {
            partcounter.update(10)
            //counter(page).update(1)
          } else if it.numbering != none and partcounter.at(loc).first() < 20 {
            partcounter.update(20)
            //counter(page).update(1)
          } 
        }
      
      if it.numbering != none {
        chaptercounter.step()
      }
      

      
      footnotecounter.update(())
      imagecounter.update(())
      tablecounter.update(())
      rawcounter.update(())
      equationcounter.update(())

      set align(center)

      // 设置heading样式
      showHeading(it, 字号.三号, hard_above: 27pt, below: 29pt)
    } else {
      
      if it.level == 2 {
        showHeading(it, 字号.四号, above: 32pt, below: 16pt)
      } else if it.level == 3 {
        showHeading(it, 字号.中四, above: 21pt, below: 16pt)
      } else {
        showHeading(it, 字号.小四, above: 21pt, below: 16pt)
      }
      
    }
  }
  
  show figure: it => [
    #set align(center)
    
    #if not it.has("kind") {
      it
    } else if it.kind == image {
      it.body
      [
        #set text(11pt)
        #v(-2pt)
        #it.caption
        #v(11pt)
      ]
    } else if it.kind == table {
      [
        #set text(11pt)
        //#it.caption
      ]
      it.body
    } else if it.kind == "code" {
      [
        #set text(11pt)
        代码#it.caption
      ]
      it.body
    }
  ]

  show ref: it => {
    if it.element == none {
      // Keep citations as is
      it
    } else {
      // Remove prefix spacing
      h(0em, weak: true)

      let el = it.element
      let el_loc = el.location()
      if el.func() == math.equation {
        // Handle equations
        link(el_loc, [
          Formula
          #chinesenumbering(chaptercounter.at(el_loc).first(), equationcounter.at(el_loc).first(), location: el_loc, brackets: true)
        ])
      } else if el.func() == figure {
        // Handle figures
        if el.kind == image {
          link(el_loc, [
            Figure
            #chinesenumbering(chaptercounter.at(el_loc).first(), imagecounter.at(el_loc).first(), location: el_loc)
            //#h(0.5em)
          ])
        } else if el.kind == table {
          link(el_loc, [
            Table
            #chinesenumbering(chaptercounter.at(el_loc).first(), tablecounter.at(el_loc).first(), location: el_loc)
            //#h(0.5em)
          ])
        } else if el.kind == "code" {
          link(el_loc, [
            Code
            #chinesenumbering(chaptercounter.at(el_loc).first(), rawcounter.at(el_loc).first(), location: el_loc)
          ])
        }
      } else if el.func() == heading {
        // Handle headings
        if el.level == 1 {
          link(el_loc, [
            Chapter
            #chinesenumbering(..counter(heading).at(el_loc), location: el_loc)
          ])
        } else {
          link(el_loc, [
            Section
            #chinesenumbering(..counter(heading).at(el_loc), location: el_loc)
          ])
        }
      }

      // Remove suffix spacing
      h(0em, weak: true)
    }
  }

  let scatterChars(str, width: none) = {
    set align(left)
    if width == none{
      str
    } else {
      box(
      width: width,
      stack(
        dir: ltr,
        ..str.clusters().map(x => [#x]).intersperse(1fr),
      ),
    )
    }
  }




  
// 封面

  set page(margin: (x: 4cm, y: 6cm))
  set align(top)
  set par(spacing: 1em)
  // place(rect( width: 100%,height: 100%,)) //显示页边距
  v(5pt)
  text(字号.一号, font: 字体.黑体)[#论文题目]

  v(7pt)
  text(字号.小二, font: 字体.宋体, tracking: 1pt)[（#副标题）]
  
  set text(字号.三号, font: 字体.仿宋)


  set align(bottom)
  let coverInfoKeyWidth = 5em
  grid(
    rows: 12pt,
    columns: (5em,2em, auto),
    row-gutter: 1.2em,
    scatterChars("培养单位", width: coverInfoKeyWidth),h(0.5em)+"：",
    scatterChars(院系),
    
    scatterChars("学科", width: coverInfoKeyWidth),h(0.5em)+"：",
    scatterChars(专业),
    
    scatterChars("研究生", width: coverInfoKeyWidth),h(0.5em)+"：",
    scatterChars(作者名, width: 4em),
    
    scatterChars("指导教师", width: coverInfoKeyWidth),h(0.5em)+"：",
    scatterChars(导师, width: 8em),

    if 副导师 != none{
      grid(
        rows: 12pt,
        columns: (5em,2em, auto),
        row-gutter: 1.2em,
        scatterChars("副指导教师", width: coverInfoKeyWidth),h(0.5em)+"：",
        scatterChars(副导师, width: 8em), 
      )
   }
  )
  
  
  v(55pt)
   text(字号.三号, font: 字体.宋体)[
    #str(int-to-cn-simple-num(日期.year())+"年"+chinesenumber(日期.month(),standalone: true)+"月")
  ]
  v(15pt)



  // English abstract
  set page(numbering: "I", margin: 3cm)
  counter(page).update(1)
  set align(left + top)
  set text(字号.小四, font: 字体.宋体)
  heading(numbering: none, outlined: true, "Abstract")
  set par(first-line-indent: (amount: 2em,all: true), justify: true)

  
  others.摘要_英

  linebreak()
  linebreak()
  set par(first-line-indent: 0em)
  [*Keywords:* ]
  关键词_英.join("; ")


  
// 目录

show outline.entry.where(level: 1):it=>{
  set par(spacing: 15pt)
  set text(字号.小四, font: 字体.黑体)
  //it.prefix()
  let loc = it.element.location()
  let actual_loc=query(selector(<__footer__>).after(loc)).first().location()
  let chap = counter("chapter").at(actual_loc).last()
  if chap > 0 and it.element.numbering != none{
    chinesenumbering(chap,location: loc)+h(1em)
  }
  
  it.body()
  set text(font: 字体.宋体)
  box(width: 1fr, it.fill)
  it.page()
  parbreak();
}
show outline.entry.where(level:2): set block(above: 0.8em)
show outline.entry.where(level:3): set block(above: 0.8em)

outline(
  title: "Outline",
  depth: 目录深度,
  indent: 1em,
)






// 正文内容
  
set align(left + top)
set par(first-line-indent: (amount: 2em, all: true), justify: true)
set text(字号.小四, font: 字体.宋体)
set figure.caption(separator: h(1em))
set page(numbering: "1")
counter(page).update(1)


doc


}
